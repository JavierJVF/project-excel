<?php

class ExcelFileModel 
{

    private $conn;

    public function __construct()
    {
        
        $bd = new Conexion();
        $this->conn = $bd->getConn();
    }

    public function create($excel)
    {
        $sql = 'INSERT INTO logs (excel_dir,excel_name, log_dir) VALUES (
            "'.$excel['excel_dir'].'",
            "'.$excel['excel_name'].'",
            "'.$excel['log_dir'].'"
            )';
        
        $result = $this->conn->query($sql);
        
        if($result) return mysqli_insert_id($this->conn);
        else return false;
    }

    public function findById($artwork)
    {
        $sql = 'SELECT *, artworks.id as id, awards.id as award_id, outstanding_images.id as outstanding_image_id, 
        (SELECT coin FROM contracts WHERE contracts.user_id = awards.user_id) as coin 
        FROM artworks 
        LEFT JOIN awards ON artworks.id = awards.artwork_id 
        LEFT JOIN outstanding_images ON artworks.id = outstanding_images.artwork_id 
        WHERE artworks.id = "'.$artwork->getId().'" LIMIT 1';

        $result = $this->conn->query($sql);

        if($result->num_rows == 1)
        {
            $data = $result->fetch_assoc();
            return $data;
        }else
        {
            return false;
        }
    }



    
}