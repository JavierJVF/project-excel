<?php
    session_start();
    require '../vendor/autoload.php';
    require_once 'Conexion.php';
    require_once 'Model/RegistroEnvioModel.php';
    require_once 'Model/ExcelFileModel.php';
    require_once 'LogFilesClass.php';
    use PhpOffice\PhpSpreadsheet\IOFactory;
    use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

    function Response($code,$mensaje,$data){
        $response['code'] = $code;
        $response['data'] = $data;
        $response['mensaje'] = $mensaje;
        
        return $response;
    }

    function rellenar_parametros_vacios($registro,$model, $log, $num_fila){
        if($registro['codigo_aduana'] == '' || $registro['codigo_aduana'] == null){
            if($registro['nombre_aduana'] != '' && $registro['nombre_aduana'] != null){
                $data = $model->findCodeAduanaByName($registro);
                if($data){
                    $registro['codigo_aduana'] = $data['codigo_aduana'];
                    $log->mensaje_registro_rellenado('codigo_aduana',$num_fila);
                }else{
                    $log->mensaje_registro_no_rellenado('codigo_aduana',$num_fila);
                }
            }else{
                $log->mensaje_registro_no_rellenado_2('aduana',$num_fila);
            }
            
        }

        if($registro['codigo_bandera'] == '' || $registro['codigo_bandera'] == null){
            if($registro['nombre_pais_bandera'] != '' && $registro['nombre_pais_bandera'] != null){
                $data = $model->findCodePaisByName($registro);
                if($data){
                    $registro['codigo_bandera'] = $data['codigo_bandera'];
                    $log->mensaje_registro_rellenado('codigo_bandera',$num_fila);
                }else{
                    $log->mensaje_registro_no_rellenado('codigo_bandera',$num_fila);
                }
            }else{
                $log->mensaje_registro_no_rellenado_2('bandera',$num_fila);
            }
            
        }

        if($registro['codigo_tipo_contenedor'] == '' || $registro['codigo_tipo_contenedor'] != null){
            if($registro['descripcion_tipo_contenedor'] != '' && $registro['descripcion_tipo_contenedor'] == null){
                $data = $model->findCodeContenedorByName($registro);
                if($data){
                    $registro['codigo_tipo_contenedor'] = $data['codigo_tipo_contenedor'];
                    $log->mensaje_registro_rellenado('codigo_tipo_contenedor',$num_fila);
                }else{
                    $log->mensaje_registro_no_rellenado('codigo_tipo_contenedor',$num_fila);
                }
            }else{
                $log->mensaje_registro_no_rellenado_2('contenedor',$num_fila);
            }
            
        }

        if($registro['codigo_lugar_embarque'] == '' || $registro['codigo_lugar_embarque'] == null){
            if($registro['nombre_lugar_embarque'] != '' && $registro['nombre_lugar_embarque'] != null){
                $data = $model->findCodeEmbarqueByName($registro);
                if($data){
                    $registro['codigo_lugar_embarque'] = $data['codigo_lugar_embarque'];
                    $log->mensaje_registro_rellenado('codigo_lugar_embarque',$num_fila);
                }else{
                    $log->mensaje_registro_no_rellenado('codigo_lugar_embarque',$num_fila);
                }
            }else{
                $log->mensaje_registro_no_rellenado_2('embarque',$num_fila);
            }
            
        }

        if($registro['codigo_lugar_desembarque'] == '' || $registro['codigo_lugar_desembarque'] == null){
            if($registro['nombre_lugar_desembarque'] != '' && $registro['nombre_lugar_desembarque'] != null){
                $data = $model->findCodeDesembarqueByName($registro);
                if($data){
                    $registro['codigo_lugar_desembarque'] = $data['codigo_lugar_desembarque'];
                    $log->mensaje_registro_rellenado('codigo_lugar_desembarque',$num_fila);
                }else{
                    $log->mensaje_registro_no_rellenado('codigo_lugar_desembarque',$num_fila);
                }
            }else{
                $log->mensaje_registro_no_rellenado_2('desembarque',$num_fila);
            }
            
        }

        if($registro['codigo_transportista'] == '' || $registro['codigo_transportista'] == null){
            if($registro['nombre_transportista'] != '' && $registro['nombre_transportista'] != null){
                $data = $model->findCodeTransportistaByName($registro);
                if($data){
                    $registro['codigo_transportista'] = $data['codigo_transportista'];
                    $log->mensaje_registro_rellenado('codigo_transportista',$num_fila);
                }else{
                    $log->mensaje_registro_no_rellenado('codigo_transportista',$num_fila);
                }
            }else{
                $log->mensaje_registro_no_rellenado_2('transportista',$num_fila);
            }
            
        }

        if($registro['codigo_exportador'] == '' || $registro['codigo_exportador'] == null){
            if($registro['nombre_exportador'] != '' && $registro['nombre_exportador'] != null){
                $data = $model->findCodeExportadorByName($registro);
                if($data){
                    $registro['codigo_exportador'] = $data['codigo_exportador'];
                    $log->mensaje_registro_rellenado('codigo_exportador',$num_fila);
                }else{
                    $log->mensaje_registro_no_rellenado('codigo_exportador',$num_fila);
                }
            }else{
                $log->mensaje_registro_no_rellenado_2('exportador',$num_fila);
            }
            
        }

        if($registro['codigo_consignatario'] == '' || $registro['codigo_consignatario'] == null){
            if($registro['nombre_consignatario'] != '' && $registro['nombre_consignatario'] != null){
                $data = $model->findCodeConsignatarioByName($registro);
                if($data){
                    $registro['codigo_consignatario'] = $data['codigo_consignatario'];
                    $log->mensaje_registro_rellenado('codigo_consignatario',$num_fila);
                }else{
                    $log->mensaje_registro_no_rellenado('codigo_consignatario',$num_fila);
                }
            }else{
                $log->mensaje_registro_no_rellenado_2('consignatario',$num_fila);
            }
            
        }

        if($registro['codigo_embalaje'] == '' || $registro['codigo_embalaje'] == null){
            if($registro['nombre_embalaje'] != '' && $registro['nombre_embalaje'] != null){
                $data = $model->findCodeEmbalajeByName($registro);
                if($data){
                    $registro['codigo_embalaje'] = $data['codigo_embalaje'];
                    $log->mensaje_registro_rellenado('codigo_embalaje',$num_fila);
                }else{
                    $log->mensaje_registro_no_rellenado('codigo_embalaje',$num_fila);
                }
            }else{
                $log->mensaje_registro_no_rellenado_2('embalaje',$num_fila);
            }
            
        }

        if($registro['codigo_localizacion'] == '' || $registro['codigo_localizacion'] == null){
            if($registro['nombre_localizacion'] != '' && $registro['nombre_localizacion'] != null){
                $data = $model->findCodeLocalizacionByName($registro);
                if($data){
                    $registro['codigo_localizacion'] = $data['codigo_localizacion'];
                    $log->mensaje_registro_rellenado('codigo_localizacion',$num_fila);
                }else{
                    $log->mensaje_registro_no_rellenado('codigo_localizacion',$num_fila);
                }
            }else{
                $log->mensaje_registro_no_rellenado_2('localizacion',$num_fila);
            }
            
        }
        return $registro;
    }


    function validar_repetidos($registro,$model, $log, $num_fila){
        $data = $model->findEnviosByAllCodes($registro);

        if($data){
            $log->mensaje_registro_envio_repetido($num_fila);
            return false;
        }else{
            return true;
        }
    }


    function store(){
        if(!isset($_FILES['excelFile'])) return Response(400,'Bad Request',null);

        $mensaje = '';

        $doc = IOFactory::load($_FILES['excelFile']['tmp_name']);
        $total_hojas = $doc->getSheetCount();

        if($total_hojas < 1) return Response(400,'El archivo no tiene hojas',null);

        $primeraHoja = $doc->getSheet(0);

        $tope_filas = $primeraHoja->getHighestDataRow();
        $tope_columnas_letra = $primeraHoja->getHighestColumn();

        $tope_columnas = Coordinate::columnIndexFromString($tope_columnas_letra);
        if ($tope_columnas < 39) return Response(400,'Al archivo le faltan columnas',null);

        
        $log = new LogFiles($_FILES['excelFile']);
        $log->mensaje_inicio_importacion();

        try {
            $log->saveXLSX();
            $log->mensaje_archivo_nombre_servidor();
            
        } catch (\Throwable $th) {
            $log->mensaje_arror_guardar_archivo();
            return Response(500,'Internal Server Error',null);
        }

        $modelExcelFile = new ExcelFileModel();
        $modelRegistroEnvio = new RegistroEnvioModel();


        try {
            $excel_id = $modelExcelFile->create($log->getFile_excel_to_save());
            if ($excel_id){
                $log->mensaje_registro_archivo_bd_positivo($excel_id);
            }else{
                $log->mensaje_registro_archivo_bd_negativo();
                return Response(500,'Internal Server Error',null);
            }
            
        } catch (\Throwable $th) {
            $log->mensaje_registro_archivo_bd_negativo();
            return Response(500,'Internal Server Error',null);
        }

        for($indexRow = 2; $indexRow < $tope_filas; $indexRow++){


            $registro = array();
            
            $registro['excel_id'] = $excel_id;
            $registro['codigo_aduana'] = $primeraHoja->getCellByColumnAndRow(1,$indexRow);
            $registro['nombre_aduana'] = $primeraHoja->getCellByColumnAndRow(2,$indexRow);
            $registro['numero_registro_manifiesto'] = $primeraHoja->getCellByColumnAndRow(3,$indexRow);
            $registro['fecha_llegada'] = $primeraHoja->getCellByColumnAndRow(4,$indexRow);
            $registro['nombre_medio_transporte'] = $primeraHoja->getCellByColumnAndRow(5,$indexRow);
            $registro['codigo_bandera'] = $primeraHoja->getCellByColumnAndRow(6,$indexRow);
            $registro['nombre_pais_bandera'] = $primeraHoja->getCellByColumnAndRow(7,$indexRow);
            $registro['documento_transporte'] = $primeraHoja->getCellByColumnAndRow(8,$indexRow);
            $registro['id_contenedor'] = $primeraHoja->getCellByColumnAndRow(9,$indexRow);
            $registro['codigo_tipo_contenedor'] = $primeraHoja->getCellByColumnAndRow(10,$indexRow);
            $registro['descripcion_tipo_contenedor'] = $primeraHoja->getCellByColumnAndRow(11,$indexRow);
            $registro['paquetes_en_contenedor'] = $primeraHoja->getCellByColumnAndRow(12,$indexRow);
            $registro['peso_contenedor'] = $primeraHoja->getCellByColumnAndRow(13,$indexRow);
            $registro['actividad'] = $primeraHoja->getCellByColumnAndRow(14,$indexRow);
            $registro['pais_embarques'] = $primeraHoja->getCellByColumnAndRow(15,$indexRow);
            $registro['codigo_lugar_embarque'] = $primeraHoja->getCellByColumnAndRow(16,$indexRow);
            $registro['nombre_lugar_embarque'] = $primeraHoja->getCellByColumnAndRow(17,$indexRow);
            $registro['pais_desembarque'] = $primeraHoja->getCellByColumnAndRow(18,$indexRow);
            $registro['codigo_lugar_desembarque'] = $primeraHoja->getCellByColumnAndRow(19,$indexRow);
            $registro['nombre_lugar_desembarque'] = $primeraHoja->getCellByColumnAndRow(20,$indexRow);
            $registro['codigo_transportista'] = $primeraHoja->getCellByColumnAndRow(21,$indexRow);
            $registro['nombre_transportista'] = $primeraHoja->getCellByColumnAndRow(22,$indexRow);
            $registro['codigo_exportador'] = $primeraHoja->getCellByColumnAndRow(23,$indexRow);
            $registro['nombre_exportador'] = $primeraHoja->getCellByColumnAndRow(24,$indexRow);
            $registro['datos_exportador'] = $primeraHoja->getCellByColumnAndRow(25,$indexRow);
            $registro['codigo_consignatario'] = $primeraHoja->getCellByColumnAndRow(26,$indexRow);
            $registro['tipo_cliente'] = $primeraHoja->getCellByColumnAndRow(27,$indexRow);
            $registro['nombre_consignatario'] = $primeraHoja->getCellByColumnAndRow(28,$indexRow);
            $registro['datos_consignatario'] = $primeraHoja->getCellByColumnAndRow(29,$indexRow);
            $registro['total_paquetes_dt'] = $primeraHoja->getCellByColumnAndRow(30,$indexRow);
            $registro['codigo_embalaje'] = $primeraHoja->getCellByColumnAndRow(31,$indexRow);
            $registro['nombre_embalaje'] = $primeraHoja->getCellByColumnAndRow(32,$indexRow);
            $registro['mercancia_agrupada'] = $primeraHoja->getCellByColumnAndRow(33,$indexRow);
            $registro['descripcion_mercancias'] = $primeraHoja->getCellByColumnAndRow(34,$indexRow);
            $registro['peso_total'] = $primeraHoja->getCellByColumnAndRow(35,$indexRow);
            $registro['monto_valor'] = $primeraHoja->getCellByColumnAndRow(36,$indexRow);
            $registro['moneda_valor'] = $primeraHoja->getCellByColumnAndRow(37,$indexRow);
            $registro['codigo_localizacion'] = $primeraHoja->getCellByColumnAndRow(38,$indexRow);
            $registro['nombre_localizacion'] = $primeraHoja->getCellByColumnAndRow(39,$indexRow);

            
            $registro_to_save = rellenar_parametros_vacios($registro,$modelRegistroEnvio,$log,$indexRow);

            if(validar_repetidos($registro_to_save,$modelRegistroEnvio,$log,$indexRow)){
                list($id_registro,$log_mensaje) = $modelRegistroEnvio->create($registro_to_save);

                if(!$id_registro){
                    $log->mensaje_log_error_al_crear_en_bd($indexRow,$log_mensaje);
                }
            }
            
        }

        $log->mensaje_fin_proceso();



        return Response(200,'success',$mensaje);
    }

    $res = store();
    header('Content-Type: application/json');
    echo json_encode($res);
?>